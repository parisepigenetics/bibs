#!/bin/bash

#SBATCH --partition=ipop-up

echo "What a nice training !"
