#!/bin/bash

#SBATCH --partition=ipop-up
#SBATCH --output flatter.out

echo "What a nice training !"
