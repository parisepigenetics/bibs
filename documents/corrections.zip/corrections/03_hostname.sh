#!/bin/bash

### SBATCH OPTIONS ###
#SBATCH --partition=ipop-up
#SBATCH --output hostname.out

### COMMANDS ###
hostname
