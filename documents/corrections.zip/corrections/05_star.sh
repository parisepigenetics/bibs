#!/bin/bash

### SBATCH OPTIONS ###
#SBATCH --partition=ipop-up
#SBATCH --job-name=Alignment
#SBATCH --output=star-alignment-%j.out
#SBATCH --error=star-alignment-%j.err
#SBATCH --mem=25G

### MODULES ###
module purge
module load star/2.7.5a

### VARIABLES ###
pathToIndex=/shared/banks/mus_musculus/mm39/star-2.7.5a
pathToFastq1=/shared/banks/mus_musculus/test_fastq/SRR9016959_R1.fastq.gz
pathToFastq2=/shared/banks/mus_musculus/test_fastq/SRR9016959_R2.fastq.gz
outputFileName=STAR_results/SRR9016959

### COMMANDS ###
STAR --genomeDir $pathToIndex \
--readFilesIn $pathToFastq1 $pathToFastq2 \
--outFileNamePrefix $outputFileName \
--readFilesCommand zcat

